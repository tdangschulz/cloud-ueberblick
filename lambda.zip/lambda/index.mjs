import { SNSClient, PublishCommand } from "@aws-sdk/client-sns";
const topicArn = "arn:aws:sns:eu-central-1:784443672563:image-email-topic";

export const handler = async (event) => {
  const s3Event = event.Records[0].s3;
  const fileName = decodeURIComponent(s3Event.object.key.replace(/\+/g, " "));
  const fileSize = s3Event.object.size;
  const fileType = s3Event.object.contentType;

  const snsClient = new SNSClient({});

  const params = {
    Message: `Die Datei wurde hochgeladen ${fileName} - ${fileSize} - ${fileType}`,
    TopicArn: topicArn,
  };

  const command = new PublishCommand(params);

  await snsClient.send(command);
};
